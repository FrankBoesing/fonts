#pragma once
#include "ILI9341_t3.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const ILI9341_t3_font_t UbuntuMono_8_Italic;
extern const ILI9341_t3_font_t UbuntuMono_9_Italic;
extern const ILI9341_t3_font_t UbuntuMono_10_Italic;
extern const ILI9341_t3_font_t UbuntuMono_11_Italic;
extern const ILI9341_t3_font_t UbuntuMono_12_Italic;
extern const ILI9341_t3_font_t UbuntuMono_13_Italic;
extern const ILI9341_t3_font_t UbuntuMono_14_Italic;
extern const ILI9341_t3_font_t UbuntuMono_15_Italic;
extern const ILI9341_t3_font_t UbuntuMono_16_Italic;
extern const ILI9341_t3_font_t UbuntuMono_17_Italic;
extern const ILI9341_t3_font_t UbuntuMono_18_Italic;
extern const ILI9341_t3_font_t UbuntuMono_20_Italic;
extern const ILI9341_t3_font_t UbuntuMono_21_Italic;
extern const ILI9341_t3_font_t UbuntuMono_22_Italic;
extern const ILI9341_t3_font_t UbuntuMono_24_Italic;
extern const ILI9341_t3_font_t UbuntuMono_26_Italic;
extern const ILI9341_t3_font_t UbuntuMono_28_Italic;
extern const ILI9341_t3_font_t UbuntuMono_32_Italic;
extern const ILI9341_t3_font_t UbuntuMono_40_Italic;
extern const ILI9341_t3_font_t UbuntuMono_48_Italic;
extern const ILI9341_t3_font_t UbuntuMono_60_Italic;
extern const ILI9341_t3_font_t UbuntuMono_72_Italic;
extern const ILI9341_t3_font_t UbuntuMono_96_Italic;

#ifdef __cplusplus
} // extern "C"
#endif
