#pragma once
#include "ILI9341_t3.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const ILI9341_t3_font_t UbuntuMono_8_Bold_Italic;
extern const ILI9341_t3_font_t UbuntuMono_9_Bold_Italic;
extern const ILI9341_t3_font_t UbuntuMono_10_Bold_Italic;
extern const ILI9341_t3_font_t UbuntuMono_11_Bold_Italic;
extern const ILI9341_t3_font_t UbuntuMono_12_Bold_Italic;
extern const ILI9341_t3_font_t UbuntuMono_13_Bold_Italic;
extern const ILI9341_t3_font_t UbuntuMono_14_Bold_Italic;
extern const ILI9341_t3_font_t UbuntuMono_15_Bold_Italic;
extern const ILI9341_t3_font_t UbuntuMono_16_Bold_Italic;
extern const ILI9341_t3_font_t UbuntuMono_17_Bold_Italic;
extern const ILI9341_t3_font_t UbuntuMono_18_Bold_Italic;
extern const ILI9341_t3_font_t UbuntuMono_20_Bold_Italic;
extern const ILI9341_t3_font_t UbuntuMono_21_Bold_Italic;
extern const ILI9341_t3_font_t UbuntuMono_22_Bold_Italic;
extern const ILI9341_t3_font_t UbuntuMono_24_Bold_Italic;
extern const ILI9341_t3_font_t UbuntuMono_26_Bold_Italic;
extern const ILI9341_t3_font_t UbuntuMono_28_Bold_Italic;
extern const ILI9341_t3_font_t UbuntuMono_32_Bold_Italic;
extern const ILI9341_t3_font_t UbuntuMono_40_Bold_Italic;
extern const ILI9341_t3_font_t UbuntuMono_48_Bold_Italic;
extern const ILI9341_t3_font_t UbuntuMono_60_Bold_Italic;
extern const ILI9341_t3_font_t UbuntuMono_72_Bold_Italic;
extern const ILI9341_t3_font_t UbuntuMono_96_Bold_Italic;

#ifdef __cplusplus
} // extern "C"
#endif
