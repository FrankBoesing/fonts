#pragma once
#include "ILI9341_t3.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const ILI9341_t3_font_t Ubuntu_8_Italic;
extern const ILI9341_t3_font_t Ubuntu_9_Italic;
extern const ILI9341_t3_font_t Ubuntu_10_Italic;
extern const ILI9341_t3_font_t Ubuntu_11_Italic;
extern const ILI9341_t3_font_t Ubuntu_12_Italic;
extern const ILI9341_t3_font_t Ubuntu_13_Italic;
extern const ILI9341_t3_font_t Ubuntu_14_Italic;
extern const ILI9341_t3_font_t Ubuntu_15_Italic;
extern const ILI9341_t3_font_t Ubuntu_16_Italic;
extern const ILI9341_t3_font_t Ubuntu_17_Italic;
extern const ILI9341_t3_font_t Ubuntu_18_Italic;
extern const ILI9341_t3_font_t Ubuntu_20_Italic;
extern const ILI9341_t3_font_t Ubuntu_21_Italic;
extern const ILI9341_t3_font_t Ubuntu_22_Italic;
extern const ILI9341_t3_font_t Ubuntu_24_Italic;
extern const ILI9341_t3_font_t Ubuntu_26_Italic;
extern const ILI9341_t3_font_t Ubuntu_28_Italic;
extern const ILI9341_t3_font_t Ubuntu_32_Italic;
extern const ILI9341_t3_font_t Ubuntu_40_Italic;
extern const ILI9341_t3_font_t Ubuntu_48_Italic;
extern const ILI9341_t3_font_t Ubuntu_60_Italic;
extern const ILI9341_t3_font_t Ubuntu_72_Italic;
extern const ILI9341_t3_font_t Ubuntu_96_Italic;

#ifdef __cplusplus
} // extern "C"
#endif
