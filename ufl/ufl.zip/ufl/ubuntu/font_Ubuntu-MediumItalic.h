#pragma once
#include "ILI9341_t3.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const ILI9341_t3_font_t UbuntuMedium_8_Italic;
extern const ILI9341_t3_font_t UbuntuMedium_9_Italic;
extern const ILI9341_t3_font_t UbuntuMedium_10_Italic;
extern const ILI9341_t3_font_t UbuntuMedium_11_Italic;
extern const ILI9341_t3_font_t UbuntuMedium_12_Italic;
extern const ILI9341_t3_font_t UbuntuMedium_13_Italic;
extern const ILI9341_t3_font_t UbuntuMedium_14_Italic;
extern const ILI9341_t3_font_t UbuntuMedium_15_Italic;
extern const ILI9341_t3_font_t UbuntuMedium_16_Italic;
extern const ILI9341_t3_font_t UbuntuMedium_17_Italic;
extern const ILI9341_t3_font_t UbuntuMedium_18_Italic;
extern const ILI9341_t3_font_t UbuntuMedium_20_Italic;
extern const ILI9341_t3_font_t UbuntuMedium_21_Italic;
extern const ILI9341_t3_font_t UbuntuMedium_22_Italic;
extern const ILI9341_t3_font_t UbuntuMedium_24_Italic;
extern const ILI9341_t3_font_t UbuntuMedium_26_Italic;
extern const ILI9341_t3_font_t UbuntuMedium_28_Italic;
extern const ILI9341_t3_font_t UbuntuMedium_32_Italic;
extern const ILI9341_t3_font_t UbuntuMedium_40_Italic;
extern const ILI9341_t3_font_t UbuntuMedium_48_Italic;
extern const ILI9341_t3_font_t UbuntuMedium_60_Italic;
extern const ILI9341_t3_font_t UbuntuMedium_72_Italic;
extern const ILI9341_t3_font_t UbuntuMedium_96_Italic;

#ifdef __cplusplus
} // extern "C"
#endif
