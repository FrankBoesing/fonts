#pragma once
#include "ILI9341_t3.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const ILI9341_t3_font_t UbuntuMedium_8;
extern const ILI9341_t3_font_t UbuntuMedium_9;
extern const ILI9341_t3_font_t UbuntuMedium_10;
extern const ILI9341_t3_font_t UbuntuMedium_11;
extern const ILI9341_t3_font_t UbuntuMedium_12;
extern const ILI9341_t3_font_t UbuntuMedium_13;
extern const ILI9341_t3_font_t UbuntuMedium_14;
extern const ILI9341_t3_font_t UbuntuMedium_15;
extern const ILI9341_t3_font_t UbuntuMedium_16;
extern const ILI9341_t3_font_t UbuntuMedium_17;
extern const ILI9341_t3_font_t UbuntuMedium_18;
extern const ILI9341_t3_font_t UbuntuMedium_20;
extern const ILI9341_t3_font_t UbuntuMedium_21;
extern const ILI9341_t3_font_t UbuntuMedium_22;
extern const ILI9341_t3_font_t UbuntuMedium_24;
extern const ILI9341_t3_font_t UbuntuMedium_26;
extern const ILI9341_t3_font_t UbuntuMedium_28;
extern const ILI9341_t3_font_t UbuntuMedium_32;
extern const ILI9341_t3_font_t UbuntuMedium_40;
extern const ILI9341_t3_font_t UbuntuMedium_48;
extern const ILI9341_t3_font_t UbuntuMedium_60;
extern const ILI9341_t3_font_t UbuntuMedium_72;
extern const ILI9341_t3_font_t UbuntuMedium_96;

#ifdef __cplusplus
} // extern "C"
#endif
