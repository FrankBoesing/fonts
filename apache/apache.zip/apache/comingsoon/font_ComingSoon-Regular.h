#pragma once
#include "ILI9341_t3.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const ILI9341_t3_font_t ComingSoon_8;
extern const ILI9341_t3_font_t ComingSoon_9;
extern const ILI9341_t3_font_t ComingSoon_10;
extern const ILI9341_t3_font_t ComingSoon_11;
extern const ILI9341_t3_font_t ComingSoon_12;
extern const ILI9341_t3_font_t ComingSoon_13;
extern const ILI9341_t3_font_t ComingSoon_14;
extern const ILI9341_t3_font_t ComingSoon_15;
extern const ILI9341_t3_font_t ComingSoon_16;
extern const ILI9341_t3_font_t ComingSoon_17;
extern const ILI9341_t3_font_t ComingSoon_18;
extern const ILI9341_t3_font_t ComingSoon_20;
extern const ILI9341_t3_font_t ComingSoon_21;
extern const ILI9341_t3_font_t ComingSoon_22;
extern const ILI9341_t3_font_t ComingSoon_24;
extern const ILI9341_t3_font_t ComingSoon_26;
extern const ILI9341_t3_font_t ComingSoon_28;
extern const ILI9341_t3_font_t ComingSoon_32;
extern const ILI9341_t3_font_t ComingSoon_40;
extern const ILI9341_t3_font_t ComingSoon_48;
extern const ILI9341_t3_font_t ComingSoon_60;
extern const ILI9341_t3_font_t ComingSoon_72;
extern const ILI9341_t3_font_t ComingSoon_96;

#ifdef __cplusplus
} // extern "C"
#endif
