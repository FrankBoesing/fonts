#pragma once
#include "ILI9341_t3.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const ILI9341_t3_font_t jsMathcmex10_8;
extern const ILI9341_t3_font_t jsMathcmex10_9;
extern const ILI9341_t3_font_t jsMathcmex10_10;
extern const ILI9341_t3_font_t jsMathcmex10_11;
extern const ILI9341_t3_font_t jsMathcmex10_12;
extern const ILI9341_t3_font_t jsMathcmex10_13;
extern const ILI9341_t3_font_t jsMathcmex10_14;
extern const ILI9341_t3_font_t jsMathcmex10_15;
extern const ILI9341_t3_font_t jsMathcmex10_16;
extern const ILI9341_t3_font_t jsMathcmex10_17;
extern const ILI9341_t3_font_t jsMathcmex10_18;
extern const ILI9341_t3_font_t jsMathcmex10_20;
extern const ILI9341_t3_font_t jsMathcmex10_21;
extern const ILI9341_t3_font_t jsMathcmex10_22;
extern const ILI9341_t3_font_t jsMathcmex10_24;
extern const ILI9341_t3_font_t jsMathcmex10_26;
extern const ILI9341_t3_font_t jsMathcmex10_28;
extern const ILI9341_t3_font_t jsMathcmex10_32;
extern const ILI9341_t3_font_t jsMathcmex10_40;
extern const ILI9341_t3_font_t jsMathcmex10_48;
extern const ILI9341_t3_font_t jsMathcmex10_60;
extern const ILI9341_t3_font_t jsMathcmex10_72;
extern const ILI9341_t3_font_t jsMathcmex10_96;

#ifdef __cplusplus
} // extern "C"
#endif
