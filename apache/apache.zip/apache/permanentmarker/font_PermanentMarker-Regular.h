#pragma once
#include "ILI9341_t3.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const ILI9341_t3_font_t PermanentMarker_8;
extern const ILI9341_t3_font_t PermanentMarker_9;
extern const ILI9341_t3_font_t PermanentMarker_10;
extern const ILI9341_t3_font_t PermanentMarker_11;
extern const ILI9341_t3_font_t PermanentMarker_12;
extern const ILI9341_t3_font_t PermanentMarker_13;
extern const ILI9341_t3_font_t PermanentMarker_14;
extern const ILI9341_t3_font_t PermanentMarker_15;
extern const ILI9341_t3_font_t PermanentMarker_16;
extern const ILI9341_t3_font_t PermanentMarker_17;
extern const ILI9341_t3_font_t PermanentMarker_18;
extern const ILI9341_t3_font_t PermanentMarker_20;
extern const ILI9341_t3_font_t PermanentMarker_21;
extern const ILI9341_t3_font_t PermanentMarker_22;
extern const ILI9341_t3_font_t PermanentMarker_24;
extern const ILI9341_t3_font_t PermanentMarker_26;
extern const ILI9341_t3_font_t PermanentMarker_28;
extern const ILI9341_t3_font_t PermanentMarker_32;
extern const ILI9341_t3_font_t PermanentMarker_40;
extern const ILI9341_t3_font_t PermanentMarker_48;
extern const ILI9341_t3_font_t PermanentMarker_60;
extern const ILI9341_t3_font_t PermanentMarker_72;
extern const ILI9341_t3_font_t PermanentMarker_96;

#ifdef __cplusplus
} // extern "C"
#endif
