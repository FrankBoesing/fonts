#pragma once
#include "ILI9341_t3.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const ILI9341_t3_font_t OpenSansCondensed_8_Bold;
extern const ILI9341_t3_font_t OpenSansCondensed_9_Bold;
extern const ILI9341_t3_font_t OpenSansCondensed_10_Bold;
extern const ILI9341_t3_font_t OpenSansCondensed_11_Bold;
extern const ILI9341_t3_font_t OpenSansCondensed_12_Bold;
extern const ILI9341_t3_font_t OpenSansCondensed_13_Bold;
extern const ILI9341_t3_font_t OpenSansCondensed_14_Bold;
extern const ILI9341_t3_font_t OpenSansCondensed_15_Bold;
extern const ILI9341_t3_font_t OpenSansCondensed_16_Bold;
extern const ILI9341_t3_font_t OpenSansCondensed_17_Bold;
extern const ILI9341_t3_font_t OpenSansCondensed_18_Bold;
extern const ILI9341_t3_font_t OpenSansCondensed_20_Bold;
extern const ILI9341_t3_font_t OpenSansCondensed_21_Bold;
extern const ILI9341_t3_font_t OpenSansCondensed_22_Bold;
extern const ILI9341_t3_font_t OpenSansCondensed_24_Bold;
extern const ILI9341_t3_font_t OpenSansCondensed_26_Bold;
extern const ILI9341_t3_font_t OpenSansCondensed_28_Bold;
extern const ILI9341_t3_font_t OpenSansCondensed_32_Bold;
extern const ILI9341_t3_font_t OpenSansCondensed_40_Bold;
extern const ILI9341_t3_font_t OpenSansCondensed_48_Bold;
extern const ILI9341_t3_font_t OpenSansCondensed_60_Bold;
extern const ILI9341_t3_font_t OpenSansCondensed_72_Bold;
extern const ILI9341_t3_font_t OpenSansCondensed_96_Bold;

#ifdef __cplusplus
} // extern "C"
#endif
