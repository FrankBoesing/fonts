#pragma once
#include "ILI9341_t3.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const ILI9341_t3_font_t Kosugi_8;
extern const ILI9341_t3_font_t Kosugi_9;
extern const ILI9341_t3_font_t Kosugi_10;
extern const ILI9341_t3_font_t Kosugi_11;
extern const ILI9341_t3_font_t Kosugi_12;
extern const ILI9341_t3_font_t Kosugi_13;
extern const ILI9341_t3_font_t Kosugi_14;
extern const ILI9341_t3_font_t Kosugi_15;
extern const ILI9341_t3_font_t Kosugi_16;
extern const ILI9341_t3_font_t Kosugi_17;
extern const ILI9341_t3_font_t Kosugi_18;
extern const ILI9341_t3_font_t Kosugi_20;
extern const ILI9341_t3_font_t Kosugi_21;
extern const ILI9341_t3_font_t Kosugi_22;
extern const ILI9341_t3_font_t Kosugi_24;
extern const ILI9341_t3_font_t Kosugi_26;
extern const ILI9341_t3_font_t Kosugi_28;
extern const ILI9341_t3_font_t Kosugi_32;
extern const ILI9341_t3_font_t Kosugi_40;
extern const ILI9341_t3_font_t Kosugi_48;
extern const ILI9341_t3_font_t Kosugi_60;
extern const ILI9341_t3_font_t Kosugi_72;
extern const ILI9341_t3_font_t Kosugi_96;

#ifdef __cplusplus
} // extern "C"
#endif
