#pragma once
#include "ILI9341_t3.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const ILI9341_t3_font_t jsMathcmmi10_8_Italic;
extern const ILI9341_t3_font_t jsMathcmmi10_9_Italic;
extern const ILI9341_t3_font_t jsMathcmmi10_10_Italic;
extern const ILI9341_t3_font_t jsMathcmmi10_11_Italic;
extern const ILI9341_t3_font_t jsMathcmmi10_12_Italic;
extern const ILI9341_t3_font_t jsMathcmmi10_13_Italic;
extern const ILI9341_t3_font_t jsMathcmmi10_14_Italic;
extern const ILI9341_t3_font_t jsMathcmmi10_15_Italic;
extern const ILI9341_t3_font_t jsMathcmmi10_16_Italic;
extern const ILI9341_t3_font_t jsMathcmmi10_17_Italic;
extern const ILI9341_t3_font_t jsMathcmmi10_18_Italic;
extern const ILI9341_t3_font_t jsMathcmmi10_20_Italic;
extern const ILI9341_t3_font_t jsMathcmmi10_21_Italic;
extern const ILI9341_t3_font_t jsMathcmmi10_22_Italic;
extern const ILI9341_t3_font_t jsMathcmmi10_24_Italic;
extern const ILI9341_t3_font_t jsMathcmmi10_26_Italic;
extern const ILI9341_t3_font_t jsMathcmmi10_28_Italic;
extern const ILI9341_t3_font_t jsMathcmmi10_32_Italic;
extern const ILI9341_t3_font_t jsMathcmmi10_40_Italic;
extern const ILI9341_t3_font_t jsMathcmmi10_48_Italic;
extern const ILI9341_t3_font_t jsMathcmmi10_60_Italic;
extern const ILI9341_t3_font_t jsMathcmmi10_72_Italic;
extern const ILI9341_t3_font_t jsMathcmmi10_96_Italic;

#ifdef __cplusplus
} // extern "C"
#endif
