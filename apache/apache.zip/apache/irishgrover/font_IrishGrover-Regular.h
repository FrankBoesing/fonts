#pragma once
#include "ILI9341_t3.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const ILI9341_t3_font_t IrishGrover_8;
extern const ILI9341_t3_font_t IrishGrover_9;
extern const ILI9341_t3_font_t IrishGrover_10;
extern const ILI9341_t3_font_t IrishGrover_11;
extern const ILI9341_t3_font_t IrishGrover_12;
extern const ILI9341_t3_font_t IrishGrover_13;
extern const ILI9341_t3_font_t IrishGrover_14;
extern const ILI9341_t3_font_t IrishGrover_15;
extern const ILI9341_t3_font_t IrishGrover_16;
extern const ILI9341_t3_font_t IrishGrover_17;
extern const ILI9341_t3_font_t IrishGrover_18;
extern const ILI9341_t3_font_t IrishGrover_20;
extern const ILI9341_t3_font_t IrishGrover_21;
extern const ILI9341_t3_font_t IrishGrover_22;
extern const ILI9341_t3_font_t IrishGrover_24;
extern const ILI9341_t3_font_t IrishGrover_26;
extern const ILI9341_t3_font_t IrishGrover_28;
extern const ILI9341_t3_font_t IrishGrover_32;
extern const ILI9341_t3_font_t IrishGrover_40;
extern const ILI9341_t3_font_t IrishGrover_48;
extern const ILI9341_t3_font_t IrishGrover_60;
extern const ILI9341_t3_font_t IrishGrover_72;
extern const ILI9341_t3_font_t IrishGrover_96;

#ifdef __cplusplus
} // extern "C"
#endif
