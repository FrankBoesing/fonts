#pragma once
#include "ILI9341_t3.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const ILI9341_t3_font_t OpenSansHebrew_8_Italic;
extern const ILI9341_t3_font_t OpenSansHebrew_9_Italic;
extern const ILI9341_t3_font_t OpenSansHebrew_10_Italic;
extern const ILI9341_t3_font_t OpenSansHebrew_11_Italic;
extern const ILI9341_t3_font_t OpenSansHebrew_12_Italic;
extern const ILI9341_t3_font_t OpenSansHebrew_13_Italic;
extern const ILI9341_t3_font_t OpenSansHebrew_14_Italic;
extern const ILI9341_t3_font_t OpenSansHebrew_15_Italic;
extern const ILI9341_t3_font_t OpenSansHebrew_16_Italic;
extern const ILI9341_t3_font_t OpenSansHebrew_17_Italic;
extern const ILI9341_t3_font_t OpenSansHebrew_18_Italic;
extern const ILI9341_t3_font_t OpenSansHebrew_20_Italic;
extern const ILI9341_t3_font_t OpenSansHebrew_21_Italic;
extern const ILI9341_t3_font_t OpenSansHebrew_22_Italic;
extern const ILI9341_t3_font_t OpenSansHebrew_24_Italic;
extern const ILI9341_t3_font_t OpenSansHebrew_26_Italic;
extern const ILI9341_t3_font_t OpenSansHebrew_28_Italic;
extern const ILI9341_t3_font_t OpenSansHebrew_32_Italic;
extern const ILI9341_t3_font_t OpenSansHebrew_40_Italic;
extern const ILI9341_t3_font_t OpenSansHebrew_48_Italic;
extern const ILI9341_t3_font_t OpenSansHebrew_60_Italic;
extern const ILI9341_t3_font_t OpenSansHebrew_72_Italic;
extern const ILI9341_t3_font_t OpenSansHebrew_96_Italic;

#ifdef __cplusplus
} // extern "C"
#endif
