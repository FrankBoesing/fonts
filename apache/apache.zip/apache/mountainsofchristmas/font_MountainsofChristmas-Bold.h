#pragma once
#include "ILI9341_t3.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const ILI9341_t3_font_t MountainsofChristmas_8_Bold;
extern const ILI9341_t3_font_t MountainsofChristmas_9_Bold;
extern const ILI9341_t3_font_t MountainsofChristmas_10_Bold;
extern const ILI9341_t3_font_t MountainsofChristmas_11_Bold;
extern const ILI9341_t3_font_t MountainsofChristmas_12_Bold;
extern const ILI9341_t3_font_t MountainsofChristmas_13_Bold;
extern const ILI9341_t3_font_t MountainsofChristmas_14_Bold;
extern const ILI9341_t3_font_t MountainsofChristmas_15_Bold;
extern const ILI9341_t3_font_t MountainsofChristmas_16_Bold;
extern const ILI9341_t3_font_t MountainsofChristmas_17_Bold;
extern const ILI9341_t3_font_t MountainsofChristmas_18_Bold;
extern const ILI9341_t3_font_t MountainsofChristmas_20_Bold;
extern const ILI9341_t3_font_t MountainsofChristmas_21_Bold;
extern const ILI9341_t3_font_t MountainsofChristmas_22_Bold;
extern const ILI9341_t3_font_t MountainsofChristmas_24_Bold;
extern const ILI9341_t3_font_t MountainsofChristmas_26_Bold;
extern const ILI9341_t3_font_t MountainsofChristmas_28_Bold;
extern const ILI9341_t3_font_t MountainsofChristmas_32_Bold;
extern const ILI9341_t3_font_t MountainsofChristmas_40_Bold;
extern const ILI9341_t3_font_t MountainsofChristmas_48_Bold;
extern const ILI9341_t3_font_t MountainsofChristmas_60_Bold;
extern const ILI9341_t3_font_t MountainsofChristmas_72_Bold;
extern const ILI9341_t3_font_t MountainsofChristmas_96_Bold;

#ifdef __cplusplus
} // extern "C"
#endif
