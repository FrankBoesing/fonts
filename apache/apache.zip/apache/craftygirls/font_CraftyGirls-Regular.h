#pragma once
#include "ILI9341_t3.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const ILI9341_t3_font_t CraftyGirls_8;
extern const ILI9341_t3_font_t CraftyGirls_9;
extern const ILI9341_t3_font_t CraftyGirls_10;
extern const ILI9341_t3_font_t CraftyGirls_11;
extern const ILI9341_t3_font_t CraftyGirls_12;
extern const ILI9341_t3_font_t CraftyGirls_13;
extern const ILI9341_t3_font_t CraftyGirls_14;
extern const ILI9341_t3_font_t CraftyGirls_15;
extern const ILI9341_t3_font_t CraftyGirls_16;
extern const ILI9341_t3_font_t CraftyGirls_17;
extern const ILI9341_t3_font_t CraftyGirls_18;
extern const ILI9341_t3_font_t CraftyGirls_20;
extern const ILI9341_t3_font_t CraftyGirls_21;
extern const ILI9341_t3_font_t CraftyGirls_22;
extern const ILI9341_t3_font_t CraftyGirls_24;
extern const ILI9341_t3_font_t CraftyGirls_26;
extern const ILI9341_t3_font_t CraftyGirls_28;
extern const ILI9341_t3_font_t CraftyGirls_32;
extern const ILI9341_t3_font_t CraftyGirls_40;
extern const ILI9341_t3_font_t CraftyGirls_48;
extern const ILI9341_t3_font_t CraftyGirls_60;
extern const ILI9341_t3_font_t CraftyGirls_72;
extern const ILI9341_t3_font_t CraftyGirls_96;

#ifdef __cplusplus
} // extern "C"
#endif
