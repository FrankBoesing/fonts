#pragma once
#include "ILI9341_t3.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const ILI9341_t3_font_t jsMathcmsy10_8;
extern const ILI9341_t3_font_t jsMathcmsy10_9;
extern const ILI9341_t3_font_t jsMathcmsy10_10;
extern const ILI9341_t3_font_t jsMathcmsy10_11;
extern const ILI9341_t3_font_t jsMathcmsy10_12;
extern const ILI9341_t3_font_t jsMathcmsy10_13;
extern const ILI9341_t3_font_t jsMathcmsy10_14;
extern const ILI9341_t3_font_t jsMathcmsy10_15;
extern const ILI9341_t3_font_t jsMathcmsy10_16;
extern const ILI9341_t3_font_t jsMathcmsy10_17;
extern const ILI9341_t3_font_t jsMathcmsy10_18;
extern const ILI9341_t3_font_t jsMathcmsy10_20;
extern const ILI9341_t3_font_t jsMathcmsy10_21;
extern const ILI9341_t3_font_t jsMathcmsy10_22;
extern const ILI9341_t3_font_t jsMathcmsy10_24;
extern const ILI9341_t3_font_t jsMathcmsy10_26;
extern const ILI9341_t3_font_t jsMathcmsy10_28;
extern const ILI9341_t3_font_t jsMathcmsy10_32;
extern const ILI9341_t3_font_t jsMathcmsy10_40;
extern const ILI9341_t3_font_t jsMathcmsy10_48;
extern const ILI9341_t3_font_t jsMathcmsy10_60;
extern const ILI9341_t3_font_t jsMathcmsy10_72;

#ifdef __cplusplus
} // extern "C"
#endif
