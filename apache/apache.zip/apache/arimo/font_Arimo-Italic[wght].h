#pragma once
#include "ILI9341_t3.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const ILI9341_t3_font_t Arimo_8_Italic;
extern const ILI9341_t3_font_t Arimo_9_Italic;
extern const ILI9341_t3_font_t Arimo_10_Italic;
extern const ILI9341_t3_font_t Arimo_11_Italic;
extern const ILI9341_t3_font_t Arimo_12_Italic;
extern const ILI9341_t3_font_t Arimo_13_Italic;
extern const ILI9341_t3_font_t Arimo_14_Italic;
extern const ILI9341_t3_font_t Arimo_15_Italic;
extern const ILI9341_t3_font_t Arimo_16_Italic;
extern const ILI9341_t3_font_t Arimo_17_Italic;
extern const ILI9341_t3_font_t Arimo_18_Italic;
extern const ILI9341_t3_font_t Arimo_20_Italic;
extern const ILI9341_t3_font_t Arimo_21_Italic;
extern const ILI9341_t3_font_t Arimo_22_Italic;
extern const ILI9341_t3_font_t Arimo_24_Italic;
extern const ILI9341_t3_font_t Arimo_26_Italic;
extern const ILI9341_t3_font_t Arimo_28_Italic;
extern const ILI9341_t3_font_t Arimo_32_Italic;
extern const ILI9341_t3_font_t Arimo_40_Italic;
extern const ILI9341_t3_font_t Arimo_48_Italic;
extern const ILI9341_t3_font_t Arimo_60_Italic;
extern const ILI9341_t3_font_t Arimo_72_Italic;
extern const ILI9341_t3_font_t Arimo_96_Italic;

#ifdef __cplusplus
} // extern "C"
#endif
