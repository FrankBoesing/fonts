#pragma once
#include "ILI9341_t3.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const ILI9341_t3_font_t Aclonica_8;
extern const ILI9341_t3_font_t Aclonica_9;
extern const ILI9341_t3_font_t Aclonica_10;
extern const ILI9341_t3_font_t Aclonica_11;
extern const ILI9341_t3_font_t Aclonica_12;
extern const ILI9341_t3_font_t Aclonica_13;
extern const ILI9341_t3_font_t Aclonica_14;
extern const ILI9341_t3_font_t Aclonica_15;
extern const ILI9341_t3_font_t Aclonica_16;
extern const ILI9341_t3_font_t Aclonica_17;
extern const ILI9341_t3_font_t Aclonica_18;
extern const ILI9341_t3_font_t Aclonica_20;
extern const ILI9341_t3_font_t Aclonica_21;
extern const ILI9341_t3_font_t Aclonica_22;
extern const ILI9341_t3_font_t Aclonica_24;
extern const ILI9341_t3_font_t Aclonica_26;
extern const ILI9341_t3_font_t Aclonica_28;
extern const ILI9341_t3_font_t Aclonica_32;
extern const ILI9341_t3_font_t Aclonica_40;
extern const ILI9341_t3_font_t Aclonica_48;
extern const ILI9341_t3_font_t Aclonica_60;
extern const ILI9341_t3_font_t Aclonica_72;
extern const ILI9341_t3_font_t Aclonica_96;

#ifdef __cplusplus
} // extern "C"
#endif
