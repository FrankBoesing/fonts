#pragma once
#include "ILI9341_t3.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const ILI9341_t3_font_t Calligraffitti_8;
extern const ILI9341_t3_font_t Calligraffitti_9;
extern const ILI9341_t3_font_t Calligraffitti_10;
extern const ILI9341_t3_font_t Calligraffitti_11;
extern const ILI9341_t3_font_t Calligraffitti_12;
extern const ILI9341_t3_font_t Calligraffitti_13;
extern const ILI9341_t3_font_t Calligraffitti_14;
extern const ILI9341_t3_font_t Calligraffitti_15;
extern const ILI9341_t3_font_t Calligraffitti_16;
extern const ILI9341_t3_font_t Calligraffitti_17;
extern const ILI9341_t3_font_t Calligraffitti_18;
extern const ILI9341_t3_font_t Calligraffitti_20;
extern const ILI9341_t3_font_t Calligraffitti_21;
extern const ILI9341_t3_font_t Calligraffitti_22;
extern const ILI9341_t3_font_t Calligraffitti_24;
extern const ILI9341_t3_font_t Calligraffitti_26;
extern const ILI9341_t3_font_t Calligraffitti_28;
extern const ILI9341_t3_font_t Calligraffitti_32;
extern const ILI9341_t3_font_t Calligraffitti_40;
extern const ILI9341_t3_font_t Calligraffitti_48;
extern const ILI9341_t3_font_t Calligraffitti_60;
extern const ILI9341_t3_font_t Calligraffitti_72;
extern const ILI9341_t3_font_t Calligraffitti_96;

#ifdef __cplusplus
} // extern "C"
#endif
