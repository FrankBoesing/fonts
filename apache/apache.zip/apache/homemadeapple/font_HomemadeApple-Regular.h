#pragma once
#include "ILI9341_t3.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const ILI9341_t3_font_t HomemadeApple_8;
extern const ILI9341_t3_font_t HomemadeApple_9;
extern const ILI9341_t3_font_t HomemadeApple_10;
extern const ILI9341_t3_font_t HomemadeApple_11;
extern const ILI9341_t3_font_t HomemadeApple_12;
extern const ILI9341_t3_font_t HomemadeApple_13;
extern const ILI9341_t3_font_t HomemadeApple_14;
extern const ILI9341_t3_font_t HomemadeApple_15;
extern const ILI9341_t3_font_t HomemadeApple_16;
extern const ILI9341_t3_font_t HomemadeApple_17;
extern const ILI9341_t3_font_t HomemadeApple_18;
extern const ILI9341_t3_font_t HomemadeApple_20;
extern const ILI9341_t3_font_t HomemadeApple_21;
extern const ILI9341_t3_font_t HomemadeApple_22;
extern const ILI9341_t3_font_t HomemadeApple_24;
extern const ILI9341_t3_font_t HomemadeApple_26;
extern const ILI9341_t3_font_t HomemadeApple_28;
extern const ILI9341_t3_font_t HomemadeApple_32;
extern const ILI9341_t3_font_t HomemadeApple_40;
extern const ILI9341_t3_font_t HomemadeApple_48;
extern const ILI9341_t3_font_t HomemadeApple_60;
extern const ILI9341_t3_font_t HomemadeApple_72;
extern const ILI9341_t3_font_t HomemadeApple_96;

#ifdef __cplusplus
} // extern "C"
#endif
