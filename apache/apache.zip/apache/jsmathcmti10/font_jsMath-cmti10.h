#pragma once
#include "ILI9341_t3.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const ILI9341_t3_font_t jsMathcmti10_8_Italic;
extern const ILI9341_t3_font_t jsMathcmti10_9_Italic;
extern const ILI9341_t3_font_t jsMathcmti10_10_Italic;
extern const ILI9341_t3_font_t jsMathcmti10_11_Italic;
extern const ILI9341_t3_font_t jsMathcmti10_12_Italic;
extern const ILI9341_t3_font_t jsMathcmti10_13_Italic;
extern const ILI9341_t3_font_t jsMathcmti10_14_Italic;
extern const ILI9341_t3_font_t jsMathcmti10_15_Italic;
extern const ILI9341_t3_font_t jsMathcmti10_16_Italic;
extern const ILI9341_t3_font_t jsMathcmti10_17_Italic;
extern const ILI9341_t3_font_t jsMathcmti10_18_Italic;
extern const ILI9341_t3_font_t jsMathcmti10_20_Italic;
extern const ILI9341_t3_font_t jsMathcmti10_21_Italic;
extern const ILI9341_t3_font_t jsMathcmti10_22_Italic;
extern const ILI9341_t3_font_t jsMathcmti10_24_Italic;
extern const ILI9341_t3_font_t jsMathcmti10_26_Italic;
extern const ILI9341_t3_font_t jsMathcmti10_28_Italic;
extern const ILI9341_t3_font_t jsMathcmti10_32_Italic;
extern const ILI9341_t3_font_t jsMathcmti10_40_Italic;
extern const ILI9341_t3_font_t jsMathcmti10_48_Italic;
extern const ILI9341_t3_font_t jsMathcmti10_60_Italic;
extern const ILI9341_t3_font_t jsMathcmti10_72_Italic;
extern const ILI9341_t3_font_t jsMathcmti10_96_Italic;

#ifdef __cplusplus
} // extern "C"
#endif
