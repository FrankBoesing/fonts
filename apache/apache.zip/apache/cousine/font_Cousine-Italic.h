#pragma once
#include "ILI9341_t3.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const ILI9341_t3_font_t Cousine_8_Italic;
extern const ILI9341_t3_font_t Cousine_9_Italic;
extern const ILI9341_t3_font_t Cousine_10_Italic;
extern const ILI9341_t3_font_t Cousine_11_Italic;
extern const ILI9341_t3_font_t Cousine_12_Italic;
extern const ILI9341_t3_font_t Cousine_13_Italic;
extern const ILI9341_t3_font_t Cousine_14_Italic;
extern const ILI9341_t3_font_t Cousine_15_Italic;
extern const ILI9341_t3_font_t Cousine_16_Italic;
extern const ILI9341_t3_font_t Cousine_17_Italic;
extern const ILI9341_t3_font_t Cousine_18_Italic;
extern const ILI9341_t3_font_t Cousine_20_Italic;
extern const ILI9341_t3_font_t Cousine_21_Italic;
extern const ILI9341_t3_font_t Cousine_22_Italic;
extern const ILI9341_t3_font_t Cousine_24_Italic;
extern const ILI9341_t3_font_t Cousine_26_Italic;
extern const ILI9341_t3_font_t Cousine_28_Italic;
extern const ILI9341_t3_font_t Cousine_32_Italic;
extern const ILI9341_t3_font_t Cousine_40_Italic;
extern const ILI9341_t3_font_t Cousine_48_Italic;
extern const ILI9341_t3_font_t Cousine_60_Italic;
extern const ILI9341_t3_font_t Cousine_72_Italic;
extern const ILI9341_t3_font_t Cousine_96_Italic;

#ifdef __cplusplus
} // extern "C"
#endif
