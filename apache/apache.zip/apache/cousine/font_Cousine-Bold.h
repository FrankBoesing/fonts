#pragma once
#include "ILI9341_t3.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const ILI9341_t3_font_t Cousine_8_Bold;
extern const ILI9341_t3_font_t Cousine_9_Bold;
extern const ILI9341_t3_font_t Cousine_10_Bold;
extern const ILI9341_t3_font_t Cousine_11_Bold;
extern const ILI9341_t3_font_t Cousine_12_Bold;
extern const ILI9341_t3_font_t Cousine_13_Bold;
extern const ILI9341_t3_font_t Cousine_14_Bold;
extern const ILI9341_t3_font_t Cousine_15_Bold;
extern const ILI9341_t3_font_t Cousine_16_Bold;
extern const ILI9341_t3_font_t Cousine_17_Bold;
extern const ILI9341_t3_font_t Cousine_18_Bold;
extern const ILI9341_t3_font_t Cousine_20_Bold;
extern const ILI9341_t3_font_t Cousine_21_Bold;
extern const ILI9341_t3_font_t Cousine_22_Bold;
extern const ILI9341_t3_font_t Cousine_24_Bold;
extern const ILI9341_t3_font_t Cousine_26_Bold;
extern const ILI9341_t3_font_t Cousine_28_Bold;
extern const ILI9341_t3_font_t Cousine_32_Bold;
extern const ILI9341_t3_font_t Cousine_40_Bold;
extern const ILI9341_t3_font_t Cousine_48_Bold;
extern const ILI9341_t3_font_t Cousine_60_Bold;
extern const ILI9341_t3_font_t Cousine_72_Bold;
extern const ILI9341_t3_font_t Cousine_96_Bold;

#ifdef __cplusplus
} // extern "C"
#endif
