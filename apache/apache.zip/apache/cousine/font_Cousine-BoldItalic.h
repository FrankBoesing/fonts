#pragma once
#include "ILI9341_t3.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const ILI9341_t3_font_t Cousine_8_Bold_Italic;
extern const ILI9341_t3_font_t Cousine_9_Bold_Italic;
extern const ILI9341_t3_font_t Cousine_10_Bold_Italic;
extern const ILI9341_t3_font_t Cousine_11_Bold_Italic;
extern const ILI9341_t3_font_t Cousine_12_Bold_Italic;
extern const ILI9341_t3_font_t Cousine_13_Bold_Italic;
extern const ILI9341_t3_font_t Cousine_14_Bold_Italic;
extern const ILI9341_t3_font_t Cousine_15_Bold_Italic;
extern const ILI9341_t3_font_t Cousine_16_Bold_Italic;
extern const ILI9341_t3_font_t Cousine_17_Bold_Italic;
extern const ILI9341_t3_font_t Cousine_18_Bold_Italic;
extern const ILI9341_t3_font_t Cousine_20_Bold_Italic;
extern const ILI9341_t3_font_t Cousine_21_Bold_Italic;
extern const ILI9341_t3_font_t Cousine_22_Bold_Italic;
extern const ILI9341_t3_font_t Cousine_24_Bold_Italic;
extern const ILI9341_t3_font_t Cousine_26_Bold_Italic;
extern const ILI9341_t3_font_t Cousine_28_Bold_Italic;
extern const ILI9341_t3_font_t Cousine_32_Bold_Italic;
extern const ILI9341_t3_font_t Cousine_40_Bold_Italic;
extern const ILI9341_t3_font_t Cousine_48_Bold_Italic;
extern const ILI9341_t3_font_t Cousine_60_Bold_Italic;
extern const ILI9341_t3_font_t Cousine_72_Bold_Italic;
extern const ILI9341_t3_font_t Cousine_96_Bold_Italic;

#ifdef __cplusplus
} // extern "C"
#endif
